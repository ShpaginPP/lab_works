#include "el.h"

el::~el(void)
{
	delete x;
}

el *el::getLink(void)
{
	return link;
}
el::el(const el &obj)
{
	x=new int(*obj.x);
	link = 0;
}

void el::setLink(el *next)
{
	link = next;
}

el::el(int a): x(new int(a))
{
	link = 0;
}

int *el::getValue()
{
	return x;
};
