#pragma once

#include "parent_q.h"

class pro_son:protected parent_q
{
public:
	parent_q *copy() override;
	float resolve() override;
	static parent_q *get_ptr();
};
