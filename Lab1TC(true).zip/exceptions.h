#pragma once

#include <iostream>

using std::ostream;

class exceptions
{
	const char *textEx;
public:
	exceptions(const char *y):textEx(y){};
	friend ostream &operator<< (ostream &stream, const exceptions &y);
};