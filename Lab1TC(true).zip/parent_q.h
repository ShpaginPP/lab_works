#pragma once

#include <iostream>
#include "el.h"
#include "exceptions.h"

using namespace std;

class parent_q
{
	el *rear;
	el *head;
public:
	parent_q ();
	parent_q (const parent_q &obj);
	virtual ~parent_q();
	el *getHead() const;
	el *getRear() const;
	void setHead(el *newHead);
	void setRear(el *newRear);
	int pop(void);
	parent_q *operator + (parent_q *op2);
	parent_q *operator + (el *op2);
	parent_q *operator = (const parent_q *op2);
	virtual float resolve() = 0;
	virtual parent_q *copy() = 0;
	friend ostream &operator<< (ostream &stream, const parent_q *myQueue);
};