#pragma once
#include <iostream>

using std::ostream;

class el
{
	int *x;
	el *link;
public:
	el(int a);
	el(const el &obj);
	~el();
	void setLink(el *next);
	el *getLink();
	int *getValue();
	friend ostream &operator << (ostream &stream,const el &myElem);
};
