#include "parent_q.h"

parent_q::parent_q()
{
	rear = nullptr;
	head = nullptr;
}

parent_q::~parent_q(void)
{	
	el *tmp = rear;
	el *tmp2;
	if(tmp!=0)
	{
		while(tmp->getLink()!=0)
		{
			tmp2 = tmp->getLink();
			delete tmp;
			tmp = tmp2;
		}
		delete tmp;
	}
}
parent_q::parent_q (const parent_q &obj)
{
	rear = nullptr;
	head = nullptr;
	el *tmp = obj.rear;
	el *tmp2;
	if(tmp!=0)
	{
		while(tmp!=0)
		{
			*this + new el(*tmp->getValue());
			tmp=tmp->getLink();
		}
	}
}

int parent_q::pop(void)
{
	if(rear == 0)
		throw exceptions("������� �����!!!");
	el *tmpRear = rear;
	el *tmpHead = head;
	head = head->getLink();
	if(tmpHead == tmpRear)
		setRear(NULL);
	el tmp = *tmpHead;	
	delete tmpHead;
	return *tmp.getValue();
} 

parent_q *parent_q::operator + (el *op2)
{
	if(rear != 0)
		rear->setLink(op2);
	else
		head = op2;
	rear = op2;
	return this;
}

el *parent_q::getHead() const
{
	return head;
};

el *parent_q::getRear() const
{
	return rear;
};

void  parent_q::setHead(el *newHead)
{
	head = newHead;
};

void  parent_q::setRear(el *newRear)
{
	rear = newRear;
};

parent_q *parent_q::operator = (const parent_q *op2)
{
	el *tmp = op2->head;
	if(op2->rear == 0)
		throw exceptions("Queue is empty!!!");
	while(tmp!=0)
	{
		(*this)+ new el(*tmp->getValue());
		tmp = tmp->getLink();
	}
	return this;
}


parent_q *parent_q::operator + (parent_q *op2)
{
	if(op2 == 0)
		throw exceptions("Copy queue, not initialization!!!");
	if(rear == 0 || op2->rear == 0)
		throw exceptions("One of the queues or both are empty!!!");
	rear->setLink(op2->head);
	rear = op2->rear;
	op2->rear = 0;
	op2->head = 0;
	return this;//��������� �� ������, ����� �������� �� ����������
}
